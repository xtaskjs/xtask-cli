# xtask-cli

Console client for bootstrapping XTaskJS applications from the official TypeScript starter and generating common source artifacts such as controllers, services, repositories, DTOs, guards, middleware, feature modules, and full resources.

## Features

- `create`: downloads `xtaskjs/typescript-starter` into a target directory
- `generate controller`: creates an XTaskJS controller skeleton
- `generate service`: creates an XTaskJS service skeleton
- `generate repository`: creates an XTaskJS repository skeleton
- `generate dto`: creates a validation DTO skeleton
- `generate guard`: creates an XTaskJS guard skeleton
- `generate middleware`: creates an XTaskJS middleware skeleton
- `generate module`: creates a feature scaffold with controller, service, repository, DTO, and barrel exports
- `generate resource`: creates controller, service, and repository files as a feature scaffold

## Install

```bash
npm install
```

## Usage

Run from source while developing:

```bash
npm run start -- --help
```

Build the CLI:

```bash
npm run build
```

Run the automated generator tests:

```bash
npm test
```

Create a new XTaskJS project:

```bash
npm run start -- create my-api
```

Skip dependency installation during project creation:

```bash
npm run start -- create my-api --skip-install
```

Generate a controller inside an existing XTaskJS app:

```bash
npm run start -- generate controller users
```

Generate a resource trio:

```bash
npm run start -- generate resource billing
```

Generate a resource scaffold with a DTO file:

```bash
npm run start -- generate resource billing --with-dto
```

Generate a CRUD-oriented resource scaffold:

```bash
npm run start -- generate resource billing --crud
```

Write a resource scaffold directly into the target directory:

```bash
npm run start -- generate resource billing --path src/modules --flat
```

Generate a DTO for request validation:

```bash
npm run start -- generate dto create-user
```

Generate a guard or middleware:

```bash
npm run start -- generate guard admin-auth
npm run start -- generate middleware request-metrics
```

Generate a feature module folder:

```bash
npm run start -- generate module billing --path src/modules
```

Generate a module and wire a guard into its controller:

```bash
npm run start -- generate module billing --path src/modules --with-guard
```

Keep a module scaffold flat in the current target path:

```bash
npm run start -- generate module billing --path src/modules/billing --flat
```

Generate files in a different source directory:

```bash
npm run start -- generate service auth --path src/modules/auth
```

## Notes

- The `create` command downloads the starter from `https://github.com/xtaskjs/typescript-starter`.
- Generated controller templates follow the decorator patterns used by XTaskJS samples and the official starter.
- `resource` and `module` scaffolds create a dedicated feature directory by default; pass `--flat` to write files directly into the chosen path.
- `--with-guard` adds a `*.guard.ts` file and applies `@UseGuards(...)` to generated module/resource controllers.
- `--with-dto` adds a `*.dto.ts` file to a resource scaffold.
- `--crud` upgrades a resource scaffold to CRUD-style controller, service, and repository methods and also generates the DTO file.
- Generated DTOs assume the target app installs `class-validator` and, when needed, `class-transformer`, matching XTaskJS validation guidance.